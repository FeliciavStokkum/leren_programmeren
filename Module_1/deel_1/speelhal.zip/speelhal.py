# Stel: je gaat met 3 vrienden (dus met zijn vieren) een dag naar de speelhal: ‘de Speelhal-dag’

# Dat kost een toegangsticket per persoon van 7,45 euro voor de hele dag. 
# Jullie willen ook met zijn allen voor 45 minuten in de VIP-VR-GameSeat. 
# De VIP-VR GameSeat kost per persoon 37 eurocent per 5 minuten. Jij trakteert dus betaal je alles.

# Maak een programma speelhal.py voor deze berekening.

toegangsticket = 7.45 * 4
vr_per_persoon = 0.37 * 9 

totaal = toegangsticket + vr_per_persoon

print(f"Je moet totaal {totaal} betalen.")