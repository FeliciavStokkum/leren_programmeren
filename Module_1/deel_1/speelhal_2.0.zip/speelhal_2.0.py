toegangsticket = 7.45 * 4
vr_per_persoon = 0.37 * 9 
aantal_personen = 4
aantal_minuten_vr = 45

totaal = toegangsticket + vr_per_persoon

print(f"Dit geweldige dagje-uit met {aantal_personen} mensen in de Speelhal met {aantal_minuten_vr} minuten VR kost je maar {totaal} euro")