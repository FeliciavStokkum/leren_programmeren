# Schrijf een functie in Python die een integer teruggeeft met het aantal tankbeurten.
# De functie heeft als parameters: kilometers_per_liter, tankinhoud, te_rijden_afstand.
# Schrijf minimaal 10 testen voor de functie!
import math

def tankbeurten(kilometers_per_liter:int, tankinhoud:int, te_rijden_afstand:int):
    kilometers_over = kilometers_per_liter * tankinhoud 
    aantal_keer_tanken = te_rijden_afstand / kilometers_over
    return math.floor(aantal_keer_tanken)

print(tankbeurten(10, 40, 30))
print(tankbeurten(5, 30, 200))
print(tankbeurten(15, 50, 1000))
print(tankbeurten(20, 60, 500))
print(tankbeurten(10, 40, 400))
print(tankbeurten(5, 30, 300))
print(tankbeurten(15, 50, 800))
print(tankbeurten(20, 60, 600))
print(tankbeurten(10, 40, 1000))
print(tankbeurten(5, 30, 1000))