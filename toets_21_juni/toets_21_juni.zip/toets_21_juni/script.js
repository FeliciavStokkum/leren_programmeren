// Schrijf een functie die je vertelt of het mogelijk is om bij het tankstation te komen of niet.
// De functie moet true teruggeven als het mogelijk is en false als dat niet zo is.

function kanBereikenTankstation(kilometersNaarTankstation, kilometersPerLiter, resterendeLiters){
    totaal_km = resterendeLiters * kilometersPerLiter 
    if (kilometersNaarTankstation < totaal_km){
        return true;
    } else {
        return false
    }

}

console.log(kanBereikenTankstation(80,10,8))
console.log(kanBereikenTankstation(10,100,10))
console.log(kanBereikenTankstation(20, 2, 5))
console.log(kanBereikenTankstation(30, 5, 5))
console.log(kanBereikenTankstation(100, 8, 13))
console.log(kanBereikenTankstation(15, 5, 2))